# រូបភាពតំណាង (Open Graph preview)

`docs/assets/preview.jpg` (1200×630) គឺជារូបដែលបង្ហាញពេលផ្ញើតំណក្នុង
Telegram / Messenger / Facebook ។

បង្កើតឡើងវិញ៖
1. កែ `og.html`
2. `node tools/og/shoot.mjs`   → `preview.png`
3. បម្លែងទៅ JPEG គុណភាព 90 → `docs/assets/preview.jpg`

ពេលប្តូររូប ត្រូវប្តូរ `?v=` ក្នុង `og:image` នៃ `docs/index.html` ផងដែរ
ដើម្បីឱ្យ Facebook/Telegram ទាញរូបថ្មី (cache ចាស់អាចនៅជាប់ច្រើនថ្ងៃ)។
