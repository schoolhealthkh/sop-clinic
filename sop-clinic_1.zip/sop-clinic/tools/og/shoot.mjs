import pw from '/home/claude/node_modules/playwright/index.js'; const { chromium } = pw;
const b = await chromium.launch({ executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
const p = await b.newPage({ viewport:{width:1200,height:630}, deviceScaleFactor:1 });
await p.goto('file:///tmp/claude-0/-home-claude/3849a50c-158e-5708-9e51-ae3d05b52b7c/scratchpad/og.html');
await p.evaluate(()=>document.fonts.ready);
await p.waitForTimeout(400);
await p.screenshot({ path:'/tmp/claude-0/-home-claude/3849a50c-158e-5708-9e51-ae3d05b52b7c/scratchpad/preview.png' });
await b.close();
console.log('ok');
